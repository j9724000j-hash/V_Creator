# Image-to-Video Motion Prompts — The Ghost of Jubb Hassan Al-Saghir

**Use:** Feed the matching still image from `02_IMAGE_PROMPTS_EN.md` into an image-to-video tool, then use the corresponding prompt below. Keep the input image as the sole visual source; the goal is to animate the existing composition, not redesign it.

## GLOBAL MOTION LOCK — apply to every scene

> Preserve the exact people, faces, child proportions, clothing, colors, props, architecture, and composition in the input image. Use restrained, cinematic motion suitable for a premium family-friendly 3D animated fantasy film. Maintain temporal consistency and stable geometry. No new characters, no new objects, no outfit or hairstyle changes, no face morphing, no extra fingers or limbs, no sudden expression changes, no violent motion, no frightening transformation, no flicker, no strobing, no melting, no warping of the well or buildings, no random camera shake, no jump cuts inside the generated clip, no captions, no text, no logos, no watermark. Natural motion blur only. One continuous shot, smooth easing, 24 fps appearance, widescreen 16:9. Keep spectral motion subtle and physically coherent. Preserve the scene's original lighting direction and cinematic color grade.

## Timing note

The edit contains **10 scenes of 12 seconds each**, for an exact final runtime of **120 seconds**. If the video tool only generates 5–8 seconds per clip, create a clean 5–8 second motion take and extend the scene to 12 seconds in the editor with a short freeze/hold and a very subtle 2D push-in or pan. Do not force unnatural motion merely to fill time. If the tool supports a full 12-second generation, use the matching scene slot duration directly.

---

## SCENE 01 — The Old Well | 00:00–00:12

**Motion prompt (English):**

> Animate this exact establishing image as one slow, continuous cinematic push-in toward the ancient well. Let the last twilight haze drift almost imperceptibly across the distant hills, and allow a few dry grass stems to move gently in a light breeze. The well and crescent-with-three-dots carving remain completely stable and unchanged. No characters appear. The camera advances only slightly over the shot, with elegant easing and a quiet sense of mystery. Keep the movement subtle enough that the viewer can absorb the location. No sudden light changes; no ghost reveal in this scene.

**Suggested motion intensity:** Low.  
**Camera:** Slow dolly-in / gentle digital push-in.

## SCENE 02 — The Light Everyone Fears | 00:12–00:24

**Motion prompt (English):**

> Animate the existing village-night composition with a very slow lateral camera drift across the stone house fronts toward the distant well. The faint cyan glow inside the well pulses only once, softly and naturally, while a thin ribbon of mist moves near the ground. If a shutter is already partly moving in the input image, let it close by a small amount; do not introduce a new person or a new action. Keep the ghost hidden. Maintain stable architecture, restrained blue lighting, and a suspenseful but gentle mood. No flickering lanterns and no sudden scares.

**Suggested motion intensity:** Low.  
**Camera:** Slow lateral drift toward the well.

## SCENE 03 — Layla Notices the Blue Trace | 00:24–00:36

**Motion prompt (English):**

> Animate Layla with only small, believable movements: one quiet blink, a slight turn of her eyes toward the blue trace outside the window, and a restrained shift of her hand around the terracotta jar. Her braid, cloak, scarf, face, and body proportions must remain unchanged. Outside the window, the existing thin cyan trace glides slowly along the lane toward the well. Warm interior light flickers very subtly like a small oil lamp, without changing its direction. Use a gentle camera push-in toward Layla's expression, ending on curiosity rather than fear. Do not make her walk through a new action that is not present in the still.

**Suggested motion intensity:** Low to medium.  
**Camera:** Slow push-in toward Layla.

## SCENE 04 — Hassan Appears | 00:36–00:48

**Motion prompt (English):**

> Preserve the exact two-character reveal. Let the thin mist curl slowly upward around the well while Hassan's existing semi-transparent cyan silhouette becomes only marginally brighter and a few tiny motes drift upward near his outline. The bronze lantern's amber light gently breathes at a very low amplitude, illuminating the same nearby stone surfaces. Layla makes a tiny, natural backward weight shift but does not change identity, clothing, or pose dramatically. Use a very slow forward camera move that increases emotional intimacy. Hassan remains kind and non-threatening; no sudden materialization, face morph, particle explosion, or horror effect.

**Suggested motion intensity:** Low.  
**Camera:** Slow push-in; keep both characters in frame.

## SCENE 05 — The Question at the Well | 00:48–01:00

**Motion prompt (English):**

> Animate the quiet two-shot with subtle eye movement and natural breathing only. Layla looks from Hassan's face to the carved symbol; Hassan makes one small, gentle pointing gesture toward the crescent-and-three-dots carving if that gesture is already supported by the input pose. The bronze lantern casts a stable amber glow with a faint soft shimmer. Keep their mouths mostly still unless the tool has reliable dialogue animation; the dialogue can be recorded as voice-over in post-production. The camera remains nearly locked, with an extremely slow cinematic push-in. Preserve all faces, hands, clothing, and stone details without deformation.

**Suggested motion intensity:** Very low.  
**Camera:** Nearly locked shot with a subtle push-in.

## SCENE 06 — The Blocked Water Channel | 01:00–01:12

**Motion prompt (English):**

> Move the camera slowly forward and slightly downward toward the narrow crack between the blocking stones. The lantern's warm beam glides gently across the stone texture without changing the object layout. Let a few dry grass tips sway and allow the very faint glint of water in the crack to shimmer subtly, as if water is moving behind the obstruction. Layla and Hassan remain nearly still, listening. Keep the well visible in its original position if it appears in the source image. No stones move yet, no water bursts out, and no new objects appear in this scene.

**Suggested motion intensity:** Low.  
**Camera:** Slow tilt-down and push toward the crack.

## SCENE 07 — One Person Cannot Move the Stone | 01:12–01:24

**Motion prompt (English):**

> Preserve Layla's effortful pose against the large stone. Add a small, believable tightening of her shoulders and a slight shift of weight, but the stone must remain completely immobile. Hassan slowly raises or angles the existing bronze lantern just enough to guide attention toward the distant village bell tower; do not invent a new light beam or magical symbol. Use a gradual rack focus from Layla and the stone toward the already visible bell tower, then hold briefly. The mood moves from frustration to realization. Avoid shaking the camera or making the stone deform.

**Suggested motion intensity:** Low to medium.  
**Camera:** Subtle rack focus toward the bell tower; almost no physical camera move.

## SCENE 08 — The Village Answers the Bell | 01:24–01:36

**Motion prompt (English):**

> Animate the existing village-square composition as a single controlled shot. Let the bronze bell swing through one measured ring cycle, and allow the rope to respond with natural weight. Layla turns her upper body slightly while pointing toward the channel; the villagers take only one or two small, coordinated steps forward, keeping their faces and clothing consistent. Lanterns sway gently and produce stable amber pools of light. Use a modest camera track that follows the direction Layla indicates, but do not cut away or create extra villagers. The feeling is purposeful cooperation, not chaos.

**Suggested motion intensity:** Medium, controlled.  
**Camera:** Gentle tracking move in the direction of the group.

## SCENE 09 — Water Returns | 01:36–01:48

**Motion prompt (English):**

> Continue the action already shown in the source image: the villagers complete a coordinated final pull on the ropes, and the clear water flows more visibly through the newly opened channel. Animate the stream with realistic continuous flow, small highlights, and modest splashes against the existing stones; do not create a flood or alter the channel's geometry. Layla and the villagers show restrained relief through tiny posture changes. Hassan's expression settles into a gentle smile while his cyan glow softens slightly. Use a smooth, small camera move toward the flowing water, keeping the characters readable. No exaggerated slow motion or explosive rock movement.

**Suggested motion intensity:** Medium.  
**Camera:** Smooth push toward the flowing water.

## SCENE 10 — Hassan's Lantern at Dawn | 01:48–02:00

**Motion prompt (English):**

> Animate the final image with a slow, tender camera push toward the bronze lantern and its reflection in the returning water. Hassan's already dissolving silhouette fades gently into a small number of fine cyan motes that drift upward and disappear; do not distort his face or body while fading, and do not make the disappearance frightening. The lantern remains solid, stationary, and sharply identifiable on the stone rim. Layla makes a very small, grateful lowering of her gaze toward the lantern. Warm dawn light gradually brightens by a subtle amount, while the water moves naturally. Finish on a calm, stable image with a brief hold for the final narration. No text or title is generated.

**Suggested motion intensity:** Low.  
**Camera:** Slow push toward lantern and water reflection; end on a gentle hold.
