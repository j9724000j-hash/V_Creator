# Image Generation Prompts — The Ghost of Jubb Hassan Al-Saghir

**Purpose:** Generate 10 cinematic stills matching `01_SCRIPT_AR.md`, plus three optional reference images that improve visual continuity. All production prompts in this file are in English.

## Workflow and prompt assembly

1. Generate Reference R1 (Layla), R2 (Hassan), and R3 (the well/location) first.
2. For each scene, use the relevant reference images as visual guidance if your generator supports image references. Treat references as identity/location anchors, not as instructions to copy their original composition.
3. For each scene image, submit: **Scene Prompt + Global Style Lock + Global Negative Prompt**. Keep the same model, aspect ratio, and style settings for all 10 scene images where possible.
4. Generate one image per scene, not a collage. Scene numbers are production labels and must not appear in the rendered image.

---

## REFERENCE R1 — Layla character reference

**Prompt (English):**

> Create a premium character-design reference image of Layla, a 10-year-old Arab village girl in a family-friendly cinematic 3D animated fantasy film. She has warm olive skin, large dark-brown eyes, soft expressive eyebrows, a small rounded nose, and long dark-brown hair gathered into one thick braid resting over her right shoulder. She wears a burnt-ochre hooded cloak, a muted teal scarf, an ivory linen tunic, a simple dark-brown belt, and worn dark-brown ankle boots. She carries a small terracotta water jar. Show her full body in a relaxed three-quarter standing pose, with a clear unobstructed silhouette and a thoughtful, brave expression. Use natural child proportions, finely textured woven fabric, subtle skin shading, beautifully groomed hair, and restrained cinematic realism. Plain neutral warm-gray studio background, soft even key light, clear separation around the silhouette, no props other than the water jar, no text, no labels, no watermark, 16:9 horizontal composition.

## REFERENCE R2 — Hassan character reference

**Prompt (English):**

> Create a premium character-design reference image of Hassan, a gentle ghost child around 9 years old, designed for a family-friendly cinematic 3D animated fantasy film. He has kind, slightly sad facial features, short softly wavy black hair, and a childlike face with no frightening details. He wears an old ivory linen tunic with a sand-colored vest and simple period-appropriate sandals. His body is semi-transparent, with a restrained pale cyan-blue inner glow and only a few tiny luminous motes near the edges. He holds one small antique bronze lantern that emits warm amber light. His silhouette must remain clearly readable despite the transparency. Full-body three-quarter standing pose, relaxed shoulders, compassionate eyes, anatomically correct child proportions, detailed fabric, subtle spectral translucency, plain neutral warm-gray studio background, soft controlled lighting, no gore, no wounds, no skeletal features, no text, no labels, no watermark, 16:9 horizontal composition.

## REFERENCE R3 — The ancient well and village architecture

**Prompt (English):**

> Create a cinematic environment-design reference for an ancient stone well called Jubb Hassan Al-Saghir, located in a fictional Levantine hillside village. The well is circular, built from weathered honey-gray sandstone blocks, with a worn low rim and a clearly recognizable carved symbol on one front-facing stone: a small crescent with exactly three dots beneath it. Nearby are old stone homes, narrow paths, dry grasses, distant rolling hills, and the suggestion of a long-dried spring channel. Architecture should feel historically timeless and regionally coherent, with no modern objects, no modern plumbing, no electricity poles, no readable signs, and no text. Twilight blue ambience with subtle warm lantern accents, cinematic atmospheric depth, richly tactile stone and earth, premium stylized 3D animated feature-film rendering, wide establishing composition, 16:9 horizontal frame.

---

## GLOBAL STYLE LOCK — append to every scene prompt

> Premium cinematic 3D animated feature-film still, high-end art direction, emotionally legible storytelling, sophisticated family-friendly dark-fantasy atmosphere, tactile physically based materials, detailed weathered Levantine stone, beautifully controlled volumetric haze, subtle atmospheric depth, cinematic global illumination, refined color grading, rich but restrained contrast, natural depth of field, realistic cloth and hair simulation, expressive yet believable faces, polished film composition, crisp subject readability, no oversharpening. Night scenes use deep midnight blue, muted teal, and pale cyan spectral light contrasted with restrained amber lantern light; dawn scenes transition to soft honey-gold and warm ivory. Preserve the exact reference designs for Layla, Hassan, the bronze lantern, the terracotta jar, the stone well, and the crescent-with-three-dots carving. One coherent fictional world. Widescreen 16:9, target 3840×2160 or highest available resolution, single still image, no panel layout, no collage, no captions.

## GLOBAL NEGATIVE PROMPT — use for every scene if supported

> text, typography, subtitles, watermark, logo, UI, collage, split screen, contact sheet, duplicate characters, extra people, extra limbs, malformed hands, fused fingers, deformed face, inconsistent clothing, changed hair or braid, changed scarf color, inconsistent ghost design, opaque human skin on ghost, skeletal ghost, zombie, gore, wounds, blood, horror monster, demonic face, exaggerated fear, modern clothes, modern buildings, cars, electric lights, plastic objects, visible wires, modern plumbing, guns, fantasy armor, neon cyberpunk colors, oversaturated glow, excessive particles, blown highlights, muddy low-resolution textures, extreme motion blur, fisheye distortion, unreadable composition.

---

## SCENE 01 — The Old Well

**Prompt (English):**

> A wide cinematic establishing shot of a small fictional Levantine stone village nestled between dry rolling hills at blue-hour dusk, before full night. In the foreground stands the ancient circular sandstone well known as Jubb Hassan Al-Saghir, its rim weathered, its basin dry, and the carved crescent with exactly three dots clearly visible on the front-facing stone. A cracked, long-dried spring channel leads away from it toward the village. Stone houses and closed wooden shutters cluster in the middle distance; no characters are visible. The sky is deep indigo with the last trace of twilight near the horizon. The composition should feel quiet, mysterious, and storybook-like rather than frightening. Use a slightly elevated wide-angle view with generous environmental context and the well as the visual anchor. [Attach R3 as location reference.]

## SCENE 02 — The Light Everyone Fears

**Prompt (English):**

> A cinematic night exterior in the same fictional Levantine village. Frame several old stone house fronts and wooden shutters in the foreground, with the ancient circular sandstone well of Jubb Hassan Al-Saghir visible in the distant background. A faint pale-cyan glow rises from inside the well and softly illuminates a thin layer of low mist; the ghost itself must NOT be clearly visible yet. One shutter is being quietly closed by a distant resident seen only as a small, non-detailed silhouette, while the rest of the village remains still. Deep midnight blues, muted teal shadows, and a tiny hint of warm amber from one oil lantern. The mood is suspenseful but gentle, with no jump-scare imagery. Use layered composition and cinematic atmospheric depth. [Attach R3 as location reference.]

## SCENE 03 — Layla Notices the Blue Trace

**Prompt (English):**

> Inside a modest old Levantine stone home at night, show Layla, a 10-year-old Arab village girl with warm olive skin, large dark-brown eyes, and one thick dark-brown braid resting over her right shoulder. She wears her consistent burnt-ochre hooded cloak, muted teal scarf, ivory linen tunic, and dark-brown ankle boots. She stands beside a small wooden window, holding a small terracotta water jar, her expression curious and cautious rather than frightened. Outside the window, a narrow trace of pale-cyan light crosses the empty stone lane toward the old well. Warm amber lamplight softly illuminates Layla's face while cool moonlight outlines her braid and cloak. Medium-wide composition, intimate interior foreground with a readable glimpse of the lane through the window. Preserve natural child anatomy and the exact outfit. [Attach R1 for Layla and R3 for architectural style.]

## SCENE 04 — Hassan Appears

**Prompt (English):**

> At the old circular sandstone well under a deep blue night sky, Layla stands close to the worn stone rim, holding her terracotta jar against her body. Keep her warm olive skin, large dark-brown eyes, single long braid over the right shoulder, burnt-ochre hooded cloak, muted teal scarf, ivory tunic, and brown boots exactly consistent with the reference. In front of her, Hassan gradually emerges from a thin veil of mist as a gentle semi-transparent ghost child around 9 years old, with softly wavy short black hair, an old ivory linen tunic, a sand-colored vest, a pale cyan-blue inner glow, and a few restrained luminous motes. He holds one small antique bronze lantern emitting warm amber light. Hassan's eyes look sad and kind, never menacing. The carved crescent with exactly three dots is visible on the well stone. Medium-wide two-character reveal, cinematic backlight and subtle fog, emotional wonder rather than horror. [Attach R1, R2, and R3.]

## SCENE 05 — The Question at the Well

**Prompt (English):**

> A quiet cinematic medium two-shot beside the same ancient sandstone well at night. Layla, with the exact reference design—10 years old, olive skin, large dark-brown eyes, one long dark braid over her right shoulder, burnt-ochre hooded cloak, muted teal scarf, ivory tunic—leans forward slightly with cautious compassion. Hassan, the semi-transparent ghost child with short softly wavy black hair, ivory tunic, sand-colored vest, pale cyan-blue spectral glow, and kind sad eyes, gently points toward the carved crescent with exactly three dots on the well. His small bronze lantern casts a warm amber pool across their faces and the textured stone. Their eye-lines meet; the scene should communicate a hushed question and a sincere answer without exaggerated mouth shapes. Blue night ambience, soft mist, restrained luminous particles, elegant depth of field, emotionally clear composition. [Attach R1, R2, and R3.]

## SCENE 06 — The Blocked Water Channel

**Prompt (English):**

> Behind the same old sandstone well, reveal a neglected ancient stone water channel almost buried beneath dry earth, tangled pale grasses, and fallen rocks. Layla kneels near a narrow crack between two heavy stones, listening carefully; her single braid, burnt-ochre hooded cloak, muted teal scarf, ivory tunic, and terracotta jar remain identical to the reference. Hassan stands beside her, his semi-transparent pale-cyan form and small bronze lantern illuminating the crack with a gentle amber-cyan contrast. A very faint glimmer of clean water is visible deep within the gap, but the channel is still blocked. The well and its crescent-with-three-dots carving are partly visible behind them to preserve geography. Low three-quarter camera angle, tactile earth and stone, cinematic mystery shifting toward hope, no modern objects. [Attach R1, R2, and R3.]

## SCENE 07 — One Person Cannot Move the Stone

**Prompt (English):**

> At the blocked ancient water channel behind the well, Layla braces both hands and one shoulder against a single enormous weathered stone, trying to move it, but the stone remains firmly lodged. Her expression shows effort turning into thoughtful realization, not panic. Preserve her exact reference design: warm olive skin, large dark-brown eyes, one thick dark-brown braid over her right shoulder, burnt-ochre hooded cloak, muted teal scarf, ivory linen tunic, dark-brown boots. Beside her, Hassan floats gently, semi-transparent and pale cyan-blue, holding his small bronze lantern. He is looking past Layla toward the distant village bell tower, which is faintly visible between the hills and rooftops. The lantern glow subtly guides the eye from the blocked stone toward the tower. Cinematic diagonal composition, moonlit atmosphere, natural physical scale, hopeful visual clue. [Attach R1, R2, and R3.]

## SCENE 08 — The Village Answers the Bell

**Prompt (English):**

> In the same fictional Levantine village square at night, Layla pulls the rope of a traditional large bronze village bell mounted in a simple stone bell frame. Her burnt-ochre hooded cloak and muted teal scarf move naturally as she acts with urgency; her single long dark-brown braid remains over her right shoulder. A small, coherent group of villagers emerges from nearby wooden doors, carrying simple coiled ropes and old hand lanterns. Their expressions shift from confusion to willingness as Layla points toward the blocked water channel. Keep the crowd modest—approximately five to seven background villagers, with no detailed individual faces competing with Layla. The old stone buildings, dry ground, and distant blue-lit well remain consistent with the setting. Warm amber lantern pools contrast with midnight-blue shadows. Medium-wide cinematic composition, strong readable silhouettes, cooperation beginning. [Attach R1 and R3.]

## SCENE 09 — Water Returns

**Prompt (English):**

> At the ancient blocked channel behind Jubb Hassan Al-Saghir, Layla and a small group of villagers work together to pull ropes and shift the loosened stones. A clear stream of water has just burst through the reopened channel and is flowing toward the village's dry spring basin, catching moonlight in silver-blue highlights. Layla remains visually consistent in her burnt-ochre hooded cloak, muted teal scarf, ivory tunic, dark-brown boots, and long single braid. Hassan stands to one side with his bronze lantern, his semi-transparent pale-cyan body glowing softly; for the first time, he wears a small peaceful smile. His design remains gentle and childlike. Show believable water flow, wet stone reflections, cooperative body language, and relief on the villagers' faces. Dynamic but clean wide-medium composition, the water is the visual payoff, uplifting cinematic atmosphere. [Attach R1, R2, and R3.]

## SCENE 10 — Hassan's Lantern at Dawn

**Prompt (English):**

> A movingly quiet dawn scene beside the same ancient sandstone well. The sky has softened from midnight blue to pale blue and warm honey-gold. Hassan, the gentle semi-transparent child ghost with softly wavy black hair, ivory tunic, sand-colored vest, and pale cyan-blue inner glow, is peacefully dissolving into a few delicate cyan motes that drift upward; no distress, no horror, no sudden disappearance effect. His small antique bronze lantern rests solidly on the worn stone rim beside the clearly visible crescent-with-exactly-three-dots carving. Layla stands nearby with her consistent long braid, burnt-ochre cloak, muted teal scarf, ivory tunic, and olive skin, looking at the lantern with quiet gratitude. In the softly blurred background, a few villagers stand beside the newly flowing spring channel. Warm dawn light reflects in the returning water; the emotional tone is tender, hopeful, and complete. Compose the lantern and water reflection as the final visual anchor. [Attach R1, R2, and R3.]
